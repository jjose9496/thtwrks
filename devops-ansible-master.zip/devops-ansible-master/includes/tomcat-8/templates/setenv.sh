#!/bin/sh
#  {{ ansible_managed }} 
export JAVA_OPTS="{{item.java_opts}}"

